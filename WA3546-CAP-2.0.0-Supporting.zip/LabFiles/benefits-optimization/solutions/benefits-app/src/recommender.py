"""
Recommender System Module for Benefits Optimization Dashboard
Implements collaborative filtering and content-based recommendations
"""

import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

class RecommenderSystem:
    def __init__(self, data_processor=None):
        self.data_processor = data_processor
        self.user_item_matrix = None
        self.item_metadata = None
        self.user_similarity = None
        self.item_similarity = None
        self.svd_model = None
        self.content_based_model = None
        
        if data_processor:
            self.initialize_recommender()
    
    def initialize_recommender(self):
        """Initialize recommender system with data"""
        self.user_item_matrix = self.data_processor.get_user_item_matrix()
        self.item_metadata = self.data_processor.get_item_metadata()
        self.build_similarity_matrices()
        self.train_svd_model()
        self.build_content_based_model()
    
    def build_similarity_matrices(self):
        """Build user-user and item-item similarity matrices"""
        # User-based similarity
        self.user_similarity = cosine_similarity(self.user_item_matrix)
        self.user_similarity = pd.DataFrame(
            self.user_similarity,
            index=self.user_item_matrix.index,
            columns=self.user_item_matrix.index
        )
        
        # Item-based similarity
        self.item_similarity = cosine_similarity(self.user_item_matrix.T)
        self.item_similarity = pd.DataFrame(
            self.item_similarity,
            index=self.user_item_matrix.columns,
            columns=self.user_item_matrix.columns
        )
    
    def train_svd_model(self):
        """Train SVD model for matrix factorization"""
        self.svd_model = TruncatedSVD(n_components=15, random_state=42)
        self.user_factors = self.svd_model.fit_transform(self.user_item_matrix)
        self.item_factors = self.svd_model.components_.T
    
    def build_content_based_model(self):
        """Build content-based recommendation model"""
        # Create item profiles
        item_features = self.item_metadata.copy()
        
        # One-hot encode BenefitType
        benefit_type_dummies = pd.get_dummies(item_features['BenefitType'], prefix='type')
        item_features = pd.concat([item_features, benefit_type_dummies], axis=1)
        
        # Normalize numerical features
        numerical_cols = ['BenefitCost', 'SatisfactionScore', 'ROI']
        for col in numerical_cols:
            if col in item_features.columns:
                item_features[col] = pd.to_numeric(item_features[col], errors='coerce')
                item_features[col] = item_features[col].fillna(item_features[col].median())
                col_min, col_max = item_features[col].min(), item_features[col].max()
                if col_max > col_min:
                    item_features[col] = (item_features[col] - col_min) / (col_max - col_min)
                else:
                    item_features[col] = 0.5
        
        # Create item profile matrix
        feature_cols = [col for col in item_features.columns if col not in ['BenefitSubType', 'BenefitType']]
        for col in feature_cols:
            item_features[col] = pd.to_numeric(item_features[col], errors='coerce').fillna(0)
        
        self.item_profiles = item_features[['BenefitSubType'] + feature_cols].set_index('BenefitSubType')
        self.item_profiles = self.item_profiles.select_dtypes(include=[np.number])
        
        # Create user profiles
        self.user_profiles = {}
        for user_id in self.user_item_matrix.index:
            user_ratings = self.user_item_matrix.loc[user_id]
            used_items = user_ratings[user_ratings > 0]
            
            if len(used_items) == 0:
                self.user_profiles[user_id] = np.zeros(len(self.item_profiles.columns))
            else:
                user_profile = np.zeros(len(self.item_profiles.columns))
                total_weight = 0
                
                for item, rating in used_items.items():
                    if item in self.item_profiles.index:
                        item_profile = self.item_profiles.loc[item].values.astype(float)
                        user_profile += float(rating) * item_profile
                        total_weight += float(rating)
                
                if total_weight > 0:
                    user_profile = user_profile / total_weight
                    
                self.user_profiles[user_id] = user_profile
    
    def get_collaborative_recommendations(self, user_id, n_recommendations=5):
        """Get collaborative filtering recommendations"""
        if user_id not in self.user_item_matrix.index:
            return []
        
        user_ratings = self.user_item_matrix.loc[user_id]
        similar_users = self.user_similarity.loc[user_id].sort_values(ascending=False)
        similar_users = similar_users.drop(user_id)
        
        recommendations = {}
        
        # Get top 20 similar users
        for similar_user in similar_users.head(20).index:
            similarity_score = similar_users[similar_user]
            if similarity_score <= 0:
                continue
                
            similar_user_ratings = self.user_item_matrix.loc[similar_user]
            
            # Find items that similar user liked but target user hasn't used
            for item in similar_user_ratings.index:
                if user_ratings[item] == 0 and similar_user_ratings[item] > 0:
                    if item not in recommendations:
                        recommendations[item] = 0
                    recommendations[item] += similarity_score * similar_user_ratings[item]
        
        # Sort and return top N
        sorted_recs = sorted(recommendations.items(), key=lambda x: x[1], reverse=True)
        return [(str(item), float(score)) for item, score in sorted_recs[:n_recommendations]]
    
    def get_content_based_recommendations(self, user_id, n_recommendations=5):
        """Get content-based recommendations"""
        if user_id not in self.user_profiles:
            return []
            
        user_profile = self.user_profiles[user_id]
        user_ratings = self.user_item_matrix.loc[user_id]
        
        # Calculate similarity between user profile and all items
        recommendations = {}
        for item in self.item_profiles.index:
            if user_ratings[item] == 0:  # Only recommend unused items
                item_profile = self.item_profiles.loc[item].values.astype(float)
                user_norm = np.linalg.norm(user_profile)
                item_norm = np.linalg.norm(item_profile)
                
                if user_norm > 0 and item_norm > 0:
                    similarity = np.dot(user_profile, item_profile) / (user_norm * item_norm)
                else:
                    similarity = 0
                    
                recommendations[item] = similarity
        
        # Sort and return top N
        sorted_recs = sorted(recommendations.items(), key=lambda x: x[1], reverse=True)
        return [(str(item), float(score)) for item, score in sorted_recs[:n_recommendations]]
    
    def get_svd_recommendations(self, user_id, n_recommendations=5):
        """Get SVD-based recommendations"""
        if user_id not in self.user_item_matrix.index:
            return []
            
        user_idx = self.user_item_matrix.index.get_loc(user_id)
        user_ratings = self.user_item_matrix.loc[user_id]
        
        # Predict ratings for all items
        predicted_ratings = {}
        for item_idx, item in enumerate(self.user_item_matrix.columns):
            if user_ratings[item] == 0:  # Only recommend items not already used
                predicted_rating = np.dot(self.user_factors[user_idx], self.item_factors[item_idx])
                predicted_ratings[item] = predicted_rating
        
        # Sort and return top N
        sorted_recs = sorted(predicted_ratings.items(), key=lambda x: x[1], reverse=True)
        return [(str(item), float(score)) for item, score in sorted_recs[:n_recommendations]]
    
    def get_hybrid_recommendations(self, user_id, n_recommendations=5):
        """Get hybrid recommendations combining all methods"""
        
        # Get recommendations from each method
        try:
            cf_recs = dict(self.get_collaborative_recommendations(user_id, n_recommendations*2))
        except:
            cf_recs = {}
            
        try:
            cb_recs = dict(self.get_content_based_recommendations(user_id, n_recommendations*2))
        except:
            cb_recs = {}
            
        try:
            svd_recs = dict(self.get_svd_recommendations(user_id, n_recommendations*2))
        except:
            svd_recs = {}
        
        # Normalize scores
        def normalize_scores(score_dict):
            if not score_dict:
                return {}
            scores = list(score_dict.values())
            min_score, max_score = min(scores), max(scores)
            if max_score == min_score:
                return {k: 0.5 for k in score_dict}
            return {k: (v - min_score) / (max_score - min_score) for k, v in score_dict.items()}
        
        cf_recs_norm = normalize_scores(cf_recs)
        cb_recs_norm = normalize_scores(cb_recs)
        svd_recs_norm = normalize_scores(svd_recs)
        
        # Combine scores
        weights = {'cf': 0.4, 'cb': 0.3, 'svd': 0.3}
        all_items = set(cf_recs_norm.keys()) | set(cb_recs_norm.keys()) | set(svd_recs_norm.keys())
        hybrid_scores = {}
        
        for item in all_items:
            score = 0
            weight_sum = 0
            
            if item in cf_recs_norm:
                score += weights['cf'] * cf_recs_norm[item]
                weight_sum += weights['cf']
            if item in cb_recs_norm:
                score += weights['cb'] * cb_recs_norm[item]
                weight_sum += weights['cb']
            if item in svd_recs_norm:
                score += weights['svd'] * svd_recs_norm[item]
                weight_sum += weights['svd']
                
            if weight_sum > 0:
                hybrid_scores[item] = score / weight_sum
        
        # Sort and return top N
        sorted_recs = sorted(hybrid_scores.items(), key=lambda x: x[1], reverse=True)
        return [(str(item), float(score)) for item, score in sorted_recs[:n_recommendations]]
    
    def get_business_recommendations(self):
        """Get business recommendations and insights"""
        if not self.data_processor:
            return {'error': 'No data processor available'}
        
        merged_data = self.data_processor.get_merged_data()
        
        # 1. Low usage, high satisfaction benefits (awareness campaigns)
        low_usage_benefits = self.user_item_matrix.mean().sort_values().head(10)
        awareness_opportunities = []
        
        for benefit, avg_usage in low_usage_benefits.items():
            benefit_info = self.item_metadata[self.item_metadata['BenefitSubType'] == benefit]
            if not benefit_info.empty:
                benefit_info = benefit_info.iloc[0]
                satisfaction = benefit_info['SatisfactionScore']
                cost = benefit_info['BenefitCost']
                
                if satisfaction >= 4.0:
                    awareness_opportunities.append({
                        'benefit': str(benefit),
                        'usage': float(round(avg_usage, 2)),
                        'satisfaction': float(round(satisfaction, 1)),
                        'cost': float(round(cost, 0)),
                        'recommendation': 'Launch awareness campaign'
                    })
        
        # 2. Upselling opportunities
        upselling_opportunities = []
        for benefit_type in merged_data['BenefitType'].unique():
            category_benefits = self.item_metadata[self.item_metadata['BenefitType'] == benefit_type]['BenefitSubType'].tolist()
            
            if len(category_benefits) > 1:
                users_partial_usage = 0
                for user_id in self.user_item_matrix.index:
                    user_usage = self.user_item_matrix.loc[user_id]
                    used_in_category = sum(1 for benefit in category_benefits if benefit in user_usage.index and user_usage[benefit] > 0)
                    total_in_category = len(category_benefits)
                    
                    if 0 < used_in_category < total_in_category:
                        users_partial_usage += 1
                
                if users_partial_usage > 0:
                    upselling_opportunities.append({
                        'category': str(benefit_type),
                        'potential_users': int(users_partial_usage),
                        'total_benefits': int(len(category_benefits)),
                        'recommendation': f'Upsell additional {benefit_type.lower()} benefits'
                    })
        
        # 3. Underperforming benefits
        underperforming = self.item_metadata.sort_values('ROI').head(5)
        underperforming_benefits = []
        
        for _, benefit_info in underperforming.iterrows():
            benefit = benefit_info['BenefitSubType']
            roi = benefit_info['ROI']
            cost = benefit_info['BenefitCost']
            satisfaction = benefit_info['SatisfactionScore']
            
            if benefit in self.user_item_matrix.columns:
                total_usage = self.user_item_matrix[benefit].sum()
                underperforming_benefits.append({
                    'benefit': str(benefit),
                    'roi': float(round(roi, 3)),
                    'total_usage': int(round(total_usage, 0)),
                    'satisfaction': float(round(satisfaction, 1)),
                    'cost': float(round(cost, 0)),
                    'recommendation': 'Consider discontinuation or restructuring'
                })
        
        # 4. Segment-specific opportunities
        segment_opportunities = []
        for segment in sorted(merged_data['employee_segment'].unique()):
            segment_data = merged_data[merged_data['employee_segment'] == segment]
            segment_size = len(segment_data)
            
            if segment_size > 50:  # Only analyze meaningful segments
                segment_usage = segment_data.groupby('BenefitSubType')['UsageFrequency'].mean()
                overall_usage = merged_data.groupby('BenefitSubType')['UsageFrequency'].mean()
                
                underutilized = []
                for benefit in segment_usage.index:
                    if benefit in overall_usage.index and segment_usage[benefit] < overall_usage[benefit] * 0.7:
                        underutilized.append({
                            'benefit': str(benefit),
                            'segment_usage': float(round(segment_usage[benefit], 1)),
                            'overall_usage': float(round(overall_usage[benefit], 1))
                        })
                
                if underutilized:
                    segment_opportunities.append({
                        'segment': str(segment),
                        'size': int(segment_size),
                        'underutilized_benefits': underutilized[:3],
                        'recommendation': 'Targeted engagement campaign'
                    })
        
        return {
            'awareness_campaigns': awareness_opportunities,
            'upselling_opportunities': upselling_opportunities,
            'underperforming_benefits': underperforming_benefits,
            'segment_opportunities': segment_opportunities,
            'summary': {
                'total_awareness_opportunities': int(len(awareness_opportunities)),
                'total_upselling_opportunities': int(len(upselling_opportunities)),
                'total_underperforming': int(len(underperforming_benefits)),
                'total_segment_opportunities': int(len(segment_opportunities))
            }
        }
    
    def get_user_recommendations(self, user_id, method='hybrid'):
        """Get recommendations for a specific user"""
        if method == 'hybrid':
            return self.get_hybrid_recommendations(user_id)
        elif method == 'collaborative':
            return self.get_collaborative_recommendations(user_id)
        elif method == 'content':
            return self.get_content_based_recommendations(user_id)
        elif method == 'svd':
            return self.get_svd_recommendations(user_id)
        else:
            return self.get_hybrid_recommendations(user_id)