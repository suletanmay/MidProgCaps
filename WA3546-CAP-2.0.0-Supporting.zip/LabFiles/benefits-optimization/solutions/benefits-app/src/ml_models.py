"""
Machine Learning Models Module for Benefits Optimization Dashboard
Implements the ML models from the notebook with proper validation
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, KFold, StratifiedKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso, LogisticRegression
from sklearn.metrics import mean_squared_error, r2_score, classification_report, roc_auc_score
import warnings
warnings.filterwarnings('ignore')

class MLModels:
    def __init__(self, data_processor):
        self.data_processor = data_processor
        self.models = {}
        self.results = {}
        self.scaler = StandardScaler()
        self.label_encoders = {}
        
    def prepare_ml_data(self):
        """Prepare data for machine learning"""
        merged_data = self.data_processor.get_merged_data()
        ml_data = merged_data.copy()
        
        # Remove non-predictive columns
        drop_cols = ['EmployeeID', 'BenefitID', 'LastUsedDate', 'Comments']
        ml_data = ml_data.drop([col for col in drop_cols if col in ml_data.columns], axis=1)
        
        # Encode categorical variables
        categorical_cols = ['Gender', 'Department', 'age_group', 'tenure_group', 'BenefitType', 'BenefitSubType']
        
        for col in categorical_cols:
            if col in ml_data.columns:
                le = LabelEncoder()
                ml_data[f'{col}_encoded'] = le.fit_transform(ml_data[col].astype(str))
                self.label_encoders[col] = le
                ml_data = ml_data.drop(col, axis=1)
        
        # Handle missing values for numeric columns only
        numeric_cols = ml_data.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            ml_data[col] = ml_data[col].fillna(ml_data[col].median())
        
        # Create target variables
        ml_data['usage_target'] = ml_data['UsageFrequency']
        ml_data['high_engagement_target'] = (ml_data['UsageFrequency'] >= ml_data['UsageFrequency'].quantile(0.7)).astype(int)
        ml_data['satisfaction_target'] = ml_data['SatisfactionScore']
        
        # Prepare feature matrix
        feature_cols = [col for col in ml_data.columns if not col.startswith(('usage_target', 'high_engagement_target', 'satisfaction_target', 'UsageFrequency', 'SatisfactionScore'))]
        X = ml_data[feature_cols]
        
        # Ensure all columns are numeric
        X = X.select_dtypes(include=[np.number])
        
        # Scale features
        X_scaled = pd.DataFrame(self.scaler.fit_transform(X), columns=X.columns, index=X.index)
        
        return X_scaled, ml_data
    
    def train_usage_prediction_models(self, X_scaled, y_usage):
        """Train models for usage prediction with proper validation"""
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y_usage, test_size=0.2, random_state=42
        )
        
        # Initialize models with regularization
        models = {
            'Linear Regression': LinearRegression(),
            'Ridge': Ridge(alpha=1.0),
            'Lasso': Lasso(alpha=0.1),
            'Random Forest': RandomForestRegressor(
                n_estimators=50,
                max_depth=10,
                min_samples_split=10,
                min_samples_leaf=5,
                random_state=42
            ),
            'Gradient Boosting': GradientBoostingRegressor(
                n_estimators=50,
                max_depth=6,
                learning_rate=0.1,
                random_state=42
            )
        }
        
        # Cross-validation
        cv = KFold(n_splits=5, shuffle=True, random_state=42)
        results = {}
        
        for name, model in models.items():
            # Cross-validation scores
            cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='neg_mean_squared_error')
            cv_r2_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='r2')
            
            # Train and test
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            
            # Store results
            results[name] = {
                'cv_r2_mean': cv_r2_scores.mean(),
                'cv_r2_std': cv_r2_scores.std(),
                'cv_mse': -cv_scores.mean(),
                'test_r2': r2_score(y_test, y_pred),
                'test_mse': mean_squared_error(y_test, y_pred),
                'model': model
            }
        
        # Select best model
        best_model_name = max(results.keys(), key=lambda x: results[x]['cv_r2_mean'])
        
        return results, best_model_name
    
    def train_engagement_prediction_models(self, X_scaled, y_engagement):
        """Train models for engagement prediction"""
        
        # Split data with stratification
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y_engagement, test_size=0.2, random_state=42, stratify=y_engagement
        )
        
        # Initialize models
        models = {
            'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
            'Ridge Logistic': LogisticRegression(penalty='l2', C=1.0, random_state=42, max_iter=1000),
            'Random Forest': RandomForestClassifier(
                n_estimators=50,
                max_depth=8,
                min_samples_split=15,
                min_samples_leaf=10,
                random_state=42
            ),
            'Gradient Boosting': GradientBoostingClassifier(
                n_estimators=50,
                max_depth=5,
                learning_rate=0.1,
                random_state=42
            )
        }
        
        # Stratified cross-validation
        cv_strat = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        results = {}
        
        for name, model in models.items():
            # Cross-validation scores
            cv_accuracy = cross_val_score(model, X_train, y_train, cv=cv_strat, scoring='accuracy')
            cv_f1 = cross_val_score(model, X_train, y_train, cv=cv_strat, scoring='f1')
            
            # Train and test
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            y_prob = model.predict_proba(X_test)[:, 1]
            
            # Store results
            results[name] = {
                'cv_accuracy': cv_accuracy.mean(),
                'cv_accuracy_std': cv_accuracy.std(),
                'cv_f1': cv_f1.mean(),
                'cv_f1_std': cv_f1.std(),
                'test_accuracy': (y_pred == y_test).mean(),
                'test_auc': roc_auc_score(y_test, y_prob),
                'model': model
            }
        
        # Select best model
        best_model_name = max(results.keys(), key=lambda x: results[x]['cv_f1'])
        
        return results, best_model_name
    
    def detect_data_leakage(self, X_scaled, y_usage, y_engagement):
        """Detect potential data leakage"""
        
        # Calculate correlations
        usage_correlations = X_scaled.corrwith(y_usage).abs().sort_values(ascending=False)
        engagement_correlations = X_scaled.corrwith(y_engagement).abs().sort_values(ascending=False)
        
        # Identify high correlations
        high_corr_usage = usage_correlations[usage_correlations > 0.7]
        high_corr_engagement = engagement_correlations[engagement_correlations > 0.7]
        
        # Check for suspicious features
        suspicious_features = []
        for feature in X_scaled.columns:
            if any(keyword in feature.lower() for keyword in ['usage', 'frequency', 'satisfaction', 'score']):
                suspicious_features.append(feature)
        
        # Create clean dataset
        leakage_features = []
        for feature in X_scaled.columns:
            if (usage_correlations[feature] > 0.8 or engagement_correlations[feature] > 0.8):
                leakage_features.append(feature)
            elif any(keyword in feature.lower() for keyword in ['usage', 'frequency', 'satisfaction', 'score', 'engagement']):
                leakage_features.append(feature)
        
        X_clean = X_scaled.drop(columns=leakage_features)
        
        return {
            'high_corr_usage': high_corr_usage.to_dict(),
            'high_corr_engagement': high_corr_engagement.to_dict(),
            'suspicious_features': suspicious_features,
            'leakage_features': leakage_features,
            'clean_features': X_clean.columns.tolist()
        }
    
    def train_all_models(self):
        """Train all ML models"""
        
        # Prepare data
        X_scaled, ml_data = self.prepare_ml_data()
        
        y_usage = ml_data['usage_target']
        y_engagement = ml_data['high_engagement_target']
        
        # Train usage prediction models
        usage_results, best_usage_model = self.train_usage_prediction_models(X_scaled, y_usage)
        
        # Train engagement prediction models
        engagement_results, best_engagement_model = self.train_engagement_prediction_models(X_scaled, y_engagement)
        
        # Detect data leakage
        leakage_analysis = self.detect_data_leakage(X_scaled, y_usage, y_engagement)
        
        # Store results
        self.results = {
            'usage_prediction': usage_results,
            'engagement_prediction': engagement_results,
            'best_usage_model': best_usage_model,
            'best_engagement_model': best_engagement_model,
            'leakage_analysis': leakage_analysis,
            'feature_names': X_scaled.columns.tolist()
        }
        
        return self.results
    
    def get_model_performance(self):
        """Get model performance summary"""
        if not self.results:
            self.train_all_models()
        
        return {
            'usage_models': {
                name: {
                    'cv_r2': f"{result['cv_r2_mean']:.3f} ± {result['cv_r2_std']:.3f}",
                    'test_r2': f"{result['test_r2']:.3f}",
                    'cv_mse': f"{result['cv_mse']:.3f}",
                    'test_mse': f"{result['test_mse']:.3f}"
                } for name, result in self.results['usage_prediction'].items()
            },
            'engagement_models': {
                name: {
                    'cv_accuracy': f"{result['cv_accuracy']:.3f} ± {result['cv_accuracy_std']:.3f}",
                    'cv_f1': f"{result['cv_f1']:.3f} ± {result['cv_f1_std']:.3f}",
                    'test_accuracy': f"{result['test_accuracy']:.3f}",
                    'test_auc': f"{result['test_auc']:.3f}"
                } for name, result in self.results['engagement_prediction'].items()
            },
            'best_models': {
                'usage': self.results['best_usage_model'],
                'engagement': self.results['best_engagement_model']
            },
            'data_quality': {
                'suspicious_features': len(self.results['leakage_analysis']['suspicious_features']),
                'leakage_features': len(self.results['leakage_analysis']['leakage_features']),
                'clean_features': len(self.results['leakage_analysis']['clean_features'])
            }
        }
    
    def get_feature_importance(self, model_type='usage'):
        """Get feature importance for the best model"""
        if not self.results:
            self.train_all_models()
        
        if model_type == 'usage':
            best_model = self.results['usage_prediction'][self.results['best_usage_model']]['model']
        else:
            best_model = self.results['engagement_prediction'][self.results['best_engagement_model']]['model']
        
        if hasattr(best_model, 'feature_importances_'):
            importance_df = pd.DataFrame({
                'feature': self.results['feature_names'],
                'importance': best_model.feature_importances_
            }).sort_values('importance', ascending=False)
            
            return importance_df.head(10).to_dict('records')
        elif hasattr(best_model, 'coef_'):
            importance_df = pd.DataFrame({
                'feature': self.results['feature_names'],
                'importance': np.abs(best_model.coef_)
            }).sort_values('importance', ascending=False)
            
            return importance_df.head(10).to_dict('records')
        else:
            return []