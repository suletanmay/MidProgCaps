"""
Data Processing Module for Benefits Optimization Dashboard
Handles data loading, cleaning, and feature engineering from the notebook analysis
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import os
import warnings
warnings.filterwarnings('ignore')

class DataProcessor:
    def __init__(self):
        self.data_path = os.path.join(os.path.dirname(__file__), '..', '..', 'assets', 'data')
        self.merged_data = None
        self.ml_data = None
        self.user_item_matrix = None
        self.item_metadata = None
        self.employee_segments = None
        self.load_and_process_data()
    
    def load_data(self):
        """Load the raw CSV files"""
        try:
            usage_data = pd.read_csv(os.path.join(self.data_path, 'usage_data.csv'))
            employee_data = pd.read_csv(os.path.join(self.data_path, 'employee_data.csv'))
            benefits_data = pd.read_csv(os.path.join(self.data_path, 'benefits_data.csv'))
            feedback_data = pd.read_csv(os.path.join(self.data_path, 'feedback_data.csv'))
            
            return usage_data, employee_data, benefits_data, feedback_data
        except Exception as e:
            raise Exception(f"Error loading data: {str(e)}")
    
    def clean_and_merge_data(self, usage_data, employee_data, benefits_data, feedback_data):
        """Clean and merge all datasets"""
        # Merge datasets
        merged = pd.merge(usage_data, employee_data, on='EmployeeID', how='inner')
        merged = pd.merge(merged, benefits_data, on='BenefitID', how='inner')
        merged = pd.merge(merged, feedback_data, on=['EmployeeID', 'BenefitID'], how='inner')
        
        # Remove outliers - specifically Monthly communications which skews ROI analysis
        print(f"Before outlier removal: {len(merged)} records")
        merged = merged[merged['BenefitSubType'] != 'Monthly communications']
        print(f"After removing Monthly communications outlier: {len(merged)} records")
        
        # Convert dates
        if 'LastUsedDate' in merged.columns:
            merged['LastUsedDate'] = pd.to_datetime(merged['LastUsedDate'], errors='coerce')
        
        # Create categorical variables
        merged['Gender'] = merged['Gender'].astype('category')
        merged['Department'] = merged['Department'].astype('category')
        
        # Feature engineering
        merged['age_group'] = pd.cut(merged['Age'], bins=[0, 30, 45, np.inf], labels=['<30', '30-45', '>45'])
        merged['tenure_group'] = pd.cut(merged['Tenure'], bins=[0, 5, 10, np.inf], labels=['<5', '5-10', '>10'])
        
        # Advanced features
        merged['age_tenure_interaction'] = merged['Age'] * merged['Tenure']
        merged['satisfaction_per_use'] = merged['SatisfactionScore'] / (merged['UsageFrequency'] + 1e-6)
        merged['cost_per_use'] = merged['BenefitCost'] / (merged['UsageFrequency'] + 1e-6)
        
        # Departmental averages
        dept_avg_usage = merged.groupby('Department')['UsageFrequency'].transform('mean')
        merged['dept_avg_usage'] = dept_avg_usage
        
        # ROI calculation
        merged['norm_cost'] = (merged['BenefitCost'] - merged['BenefitCost'].min()) / (merged['BenefitCost'].max() - merged['BenefitCost'].min())
        merged['norm_sat'] = (merged['SatisfactionScore'] - merged['SatisfactionScore'].min()) / (merged['SatisfactionScore'].max() - merged['SatisfactionScore'].min())
        merged['ROI'] = merged['norm_sat'] / (merged['norm_cost'] + 1e-5)
        
        # High engagement flag
        usage_80th = merged['UsageFrequency'].quantile(0.8)
        merged['high_engagement'] = merged['UsageFrequency'] >= usage_80th
        
        return merged
    
    def perform_segmentation(self, merged_data):
        """Perform K-means clustering for employee segmentation"""
        # Prepare clustering features
        cluster_features = ['Age', 'Tenure', 'satisfaction_per_use', 'cost_per_use']
        
        # Create feature matrix
        cluster_data = merged_data[cluster_features].fillna(merged_data[cluster_features].median())
        
        # Encode categorical variables if needed
        label_encoders = {}
        if 'Gender' in merged_data.columns:
            le_gender = LabelEncoder()
            cluster_data['Gender_encoded'] = le_gender.fit_transform(merged_data['Gender'])
            label_encoders['Gender'] = le_gender
        
        if 'Department' in merged_data.columns:
            le_dept = LabelEncoder()
            cluster_data['Department_encoded'] = le_dept.fit_transform(merged_data['Department'])
            label_encoders['Department'] = le_dept
        
        # Standardize features
        scaler = StandardScaler()
        cluster_data_scaled = scaler.fit_transform(cluster_data)
        
        # Find optimal number of clusters
        silhouette_scores = []
        k_range = range(2, 8)
        
        for k in k_range:
            kmeans = KMeans(n_clusters=k, random_state=42)
            cluster_labels = kmeans.fit_predict(cluster_data_scaled)
            silhouette_avg = silhouette_score(cluster_data_scaled, cluster_labels)
            silhouette_scores.append(silhouette_avg)
        
        optimal_k = k_range[np.argmax(silhouette_scores)]
        
        # Apply final clustering
        kmeans_final = KMeans(n_clusters=optimal_k, random_state=42)
        employee_segments = kmeans_final.fit_predict(cluster_data_scaled)
        
        return employee_segments, optimal_k, max(silhouette_scores)
    
    def create_user_item_matrix(self, merged_data):
        """Create user-item matrix for recommender system"""
        user_item_matrix = merged_data.pivot_table(
            index='EmployeeID',
            columns='BenefitSubType',
            values='UsageFrequency',
            fill_value=0
        )
        
        # Create item metadata
        item_metadata = merged_data.groupby('BenefitSubType').agg({
            'BenefitType': 'first',
            'BenefitCost': 'mean',
            'SatisfactionScore': 'mean',
            'ROI': 'mean'
        }).reset_index()
        
        return user_item_matrix, item_metadata
    
    def load_and_process_data(self):
        """Main data processing pipeline"""
        try:
            # Load raw data
            usage_data, employee_data, benefits_data, feedback_data = self.load_data()
            
            # Clean and merge
            self.merged_data = self.clean_and_merge_data(usage_data, employee_data, benefits_data, feedback_data)
            
            # Perform segmentation
            employee_segments, optimal_k, silhouette_score = self.perform_segmentation(self.merged_data)
            self.merged_data['employee_segment'] = employee_segments
            
            # Create user-item matrix
            self.user_item_matrix, self.item_metadata = self.create_user_item_matrix(self.merged_data)
            
            # Store segmentation info
            self.employee_segments = {
                'optimal_k': optimal_k,
                'silhouette_score': silhouette_score,
                'segments': employee_segments
            }
            
            print(f"Data processed successfully:")
            print(f"- Total records: {len(self.merged_data)}")
            print(f"- Unique employees: {self.merged_data['EmployeeID'].nunique()}")
            print(f"- Unique benefits: {self.merged_data['BenefitSubType'].nunique()}")
            print(f"- Employee segments: {optimal_k}")
            print(f"- Silhouette score: {silhouette_score:.3f}")
            
        except Exception as e:
            raise Exception(f"Error in data processing pipeline: {str(e)}")
    
    def get_merged_data(self):
        """Return the merged and processed data"""
        return self.merged_data.copy()
    
    def get_user_item_matrix(self):
        """Return the user-item matrix"""
        return self.user_item_matrix.copy()
    
    def get_item_metadata(self):
        """Return item metadata"""
        return self.item_metadata.copy()
    
    def get_filtered_data(self, department='all', age_group='all', benefit_type='all'):
        """Get filtered data based on parameters"""
        filtered_data = self.merged_data.copy()
        
        if department != 'all':
            filtered_data = filtered_data[filtered_data['Department'] == department]
        
        if age_group != 'all':
            filtered_data = filtered_data[filtered_data['age_group'] == age_group]
        
        if benefit_type != 'all':
            filtered_data = filtered_data[filtered_data['BenefitType'] == benefit_type]
        
        return filtered_data
    
    def get_summary_stats(self):
        """Get summary statistics for the dashboard"""
        data = self.merged_data
        
        return {
            'total_employees': data['EmployeeID'].nunique(),
            'total_benefits': data['BenefitSubType'].nunique(),
            'total_budget': data['BenefitCost'].sum(),
            'avg_satisfaction': data['SatisfactionScore'].mean(),
            'avg_usage': data['UsageFrequency'].mean(),
            'segments': self.employee_segments['optimal_k'],
            'silhouette_score': self.employee_segments['silhouette_score']
        }
    
    def get_filter_options(self):
        """Get available filter options"""
        return {
            'departments': sorted(self.merged_data['Department'].unique().tolist()),
            'age_groups': sorted(self.merged_data['age_group'].unique().tolist()),
            'benefit_types': sorted(self.merged_data['BenefitType'].unique().tolist())
        }
    
    def get_segment_analysis(self):
        """Get detailed analysis of employee segments"""
        data = self.merged_data
        
        # Group by segments and calculate detailed statistics
        segment_profiles = data.groupby('employee_segment').agg({
            'Age': ['mean', 'std'],
            'Tenure': ['mean', 'std'],
            'UsageFrequency': ['mean', 'std'],
            'SatisfactionScore': ['mean', 'std'],
            'BenefitCost': ['mean', 'sum'],
            'ROI': ['mean', 'std'],
            'EmployeeID': 'nunique',
            'Department': lambda x: x.mode().iloc[0] if not x.mode().empty else 'Mixed'
        }).round(2)
        
        # Flatten column names
        segment_profiles.columns = ['_'.join(col).strip() for col in segment_profiles.columns]
        
        # Create segment interpretations
        segment_interpretations = {}
        for segment in segment_profiles.index:
            segment_data = segment_profiles.loc[segment]
            
            # Determine segment characteristics
            avg_age = segment_data['Age_mean']
            avg_tenure = segment_data['Tenure_mean']
            avg_usage = segment_data['UsageFrequency_mean']
            avg_satisfaction = segment_data['SatisfactionScore_mean']
            avg_roi = segment_data['ROI_mean']
            employee_count = segment_data['EmployeeID_nunique']
            dominant_dept = segment_data['Department_<lambda>']
            
            # Create interpretation
            if avg_age < 35:
                age_desc = "Young"
            elif avg_age < 50:
                age_desc = "Mid-career"
            else:
                age_desc = "Senior"
            
            if avg_usage > data['UsageFrequency'].quantile(0.75):
                usage_desc = "High usage"
            elif avg_usage > data['UsageFrequency'].quantile(0.25):
                usage_desc = "Moderate usage"
            else:
                usage_desc = "Low usage"
            
            if avg_satisfaction > data['SatisfactionScore'].quantile(0.75):
                satisfaction_desc = "Highly satisfied"
            elif avg_satisfaction > data['SatisfactionScore'].quantile(0.25):
                satisfaction_desc = "Moderately satisfied"
            else:
                satisfaction_desc = "Low satisfaction"
            
            segment_interpretations[segment] = {
                'name': f"Segment {segment}",
                'description': f"{age_desc} employees with {usage_desc.lower()} and {satisfaction_desc.lower()}",
                'characteristics': {
                    'avg_age': avg_age,
                    'avg_tenure': avg_tenure,
                    'avg_usage': avg_usage,
                    'avg_satisfaction': avg_satisfaction,
                    'avg_roi': avg_roi,
                    'employee_count': employee_count,
                    'dominant_department': dominant_dept
                },
                'key_insights': [
                    f"Average age: {avg_age:.1f} years",
                    f"Average tenure: {avg_tenure:.1f} years",
                    f"Usage frequency: {avg_usage:.1f}",
                    f"Satisfaction score: {avg_satisfaction:.1f}/5",
                    f"ROI score: {avg_roi:.2f}",
                    f"Size: {employee_count} employees",
                    f"Primary department: {dominant_dept}"
                ]
            }
        
        return {
            'segment_profiles': segment_profiles.to_dict('index'),
            'segment_interpretations': segment_interpretations,
            'total_segments': len(segment_profiles)
        }