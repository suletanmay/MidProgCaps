# TechLance Benefits Optimization Analytics Dashboard

A comprehensive Flask-based analytics dashboard for optimizing employee benefits portfolio, featuring machine learning models, interactive visualizations, and strategic recommendations.

## Features

### 📊 **Executive Dashboard**
- Real-time metrics and KPIs
- Interactive Plotly charts and visualizations
- Employee segmentation analysis
- Benefit utilization tracking
- ROI analysis and cost optimization insights

### 🤖 **Machine Learning Models**
- Usage prediction models (Linear Regression, Random Forest, Gradient Boosting)
- Employee engagement classification
- Proper cross-validation and overfitting detection
- Data leakage detection and prevention
- Feature importance analysis

### 🎯 **Recommendation System**
- Collaborative filtering (User-based and Item-based)
- Content-based filtering
- Matrix factorization (SVD)
- Hybrid recommendation approach
- Business-focused recommendations

### 📈 **Strategic Reports**
- Executive summary with key findings
- Prioritized strategic recommendations
- 6-month implementation roadmap
- Cost-benefit analysis with ROI calculations
- Risk assessment and mitigation strategies
- Stakeholder analysis and communication plans

### 💡 **Interactive Features**
- Dynamic filtering (Department, Age Group, Benefit Type)
- Mobile-responsive design
- Real-time data updates
- Export capabilities (PDF, Excel)
- Drill-down analytics

## Installation

1. **Clone the repository:**
   ```bash
   cd benefits-app
   ```

2. **Create a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Ensure data files are in place:**
   - Place CSV files in `../assets/data/` directory:
     - `usage_data.csv`
     - `employee_data.csv`
     - `benefits_data.csv`
     - `feedback_data.csv`

## Usage

1. **Start the application:**
   ```bash
   python app.py
   ```

2. **Open your browser:**
   - Navigate to `http://localhost:5000`
   - Dashboard will load automatically

3. **Explore the features:**
   - **Dashboard**: Main analytics view with interactive charts
   - **Reports**: Comprehensive strategic recommendations and analysis

## API Endpoints

- `GET /api/overview` - Overview metrics and summary statistics
- `GET /api/utilization` - Benefit utilization analysis
- `GET /api/segments` - Employee segmentation analysis
- `GET /api/recommendations` - Business recommendations
- `GET /api/roi_analysis` - ROI and cost-benefit analysis
- `GET /api/filter_data` - Filtered data based on parameters
- `GET /api/generate_report` - Generate comprehensive strategic report

## Architecture

```
benefits-app/
├── app.py                 # Main Flask application
├── src/
│   ├── __init__.py
│   ├── data_processor.py  # Data loading and processing
│   ├── ml_models.py       # Machine learning models
│   ├── recommender.py     # Recommendation system
│   └── report_generator.py # Strategic report generation
├── templates/
│   ├── base.html          # Base template
│   ├── dashboard.html     # Main dashboard
│   └── reports.html       # Strategic reports
├── static/                # Static assets (CSS, JS, images)
├── requirements.txt       # Python dependencies
└── README.md             # This file
```

## Data Processing Pipeline

1. **Data Loading**: Load CSV files from assets directory
2. **Data Cleaning**: Handle missing values, duplicates, and outliers
3. **Feature Engineering**: Create derived features and interactions
4. **Employee Segmentation**: K-means clustering for employee groups
5. **ML Model Training**: Train and validate predictive models
6. **Recommendation Generation**: Build collaborative and content-based recommenders

## Machine Learning Models

### Usage Prediction Models
- **Linear Regression**: Baseline model with interpretable coefficients
- **Ridge Regression**: L2 regularization to prevent overfitting
- **Lasso Regression**: L1 regularization for feature selection
- **Random Forest**: Ensemble method with limited depth
- **Gradient Boosting**: Boosting with controlled learning rate

### Engagement Classification
- **Logistic Regression**: Binary classification for high/low engagement
- **Random Forest Classifier**: Ensemble approach for classification
- **Gradient Boosting Classifier**: Boosting for binary classification

### Validation & Quality
- **5-Fold Cross-Validation**: Robust model evaluation
- **Overfitting Detection**: Automatic warnings for suspicious performance
- **Data Leakage Detection**: Feature correlation analysis
- **Performance Benchmarking**: Realistic performance expectations

## Recommendation System

### Collaborative Filtering
- **User-Based**: Find similar users and recommend their preferences
- **Item-Based**: Recommend items similar to user's current preferences
- **Matrix Factorization**: SVD decomposition for latent factor modeling

### Content-Based Filtering
- **Item Profiles**: Features based on benefit metadata
- **User Profiles**: Weighted preferences based on usage history
- **Cosine Similarity**: Calculate similarity between profiles

### Hybrid Approach
- **Weighted Combination**: Combine multiple recommendation methods
- **Normalized Scoring**: Ensure comparable scores across methods
- **Fallback Mechanisms**: Handle cases where some methods fail

## Strategic Recommendations

### Priority Levels
- **HIGH**: Critical actions with significant impact
- **MEDIUM**: Important improvements with moderate impact
- **LOW**: Nice-to-have enhancements

### Implementation Phases
1. **Foundation (Months 1-2)**: Setup and baseline establishment
2. **Quick Wins (Months 3-4)**: High-impact, low-effort improvements
3. **Transformation (Months 5-6)**: Major changes and new implementations

### Cost-Benefit Analysis
- **Implementation Costs**: Technology, training, and consulting
- **Projected Savings**: Conservative and optimistic scenarios
- **ROI Calculations**: Multi-year return on investment
- **Sensitivity Analysis**: Risk-adjusted projections

## Security Considerations

- **Data Privacy**: No sensitive employee data stored permanently
- **Input Validation**: All user inputs validated and sanitized
- **Error Handling**: Graceful error handling without data exposure
- **Access Control**: Basic authentication mechanisms (extend as needed)

## Performance Optimization

- **Caching**: Results cached for improved response times
- **Lazy Loading**: Charts and data loaded on demand
- **Efficient Queries**: Optimized data processing and filtering
- **Mobile Responsive**: Optimized for mobile devices

## Deployment

### Local Development
```bash
python app.py
```

### Production Deployment
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Docker Deployment
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For questions or issues, please:
1. Check the documentation
2. Search existing issues
3. Create a new issue with detailed description

## Roadmap

- [ ] Advanced ML models (Deep Learning, XGBoost)
- [ ] Real-time data streaming
- [ ] Advanced visualization features
- [ ] A/B testing framework
- [ ] API rate limiting and authentication
- [ ] Automated report scheduling
- [ ] Integration with HR systems

---

**Built with ❤️ for TechLance Solutions**