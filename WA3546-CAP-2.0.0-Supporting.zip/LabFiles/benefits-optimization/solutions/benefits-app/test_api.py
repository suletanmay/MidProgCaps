#!/usr/bin/env python3
"""
Test script to verify the Flask API endpoints are working correctly
"""

import requests
import json
import time
import subprocess
import sys
import os

def test_api_endpoints():
    """Test all API endpoints"""
    
    base_url = "http://localhost:5002"
    
    endpoints = [
        '/api/overview',
        '/api/utilization',
        '/api/segments',
        '/api/recommendations',
        '/api/roi_analysis',
        '/api/filter_data',
        '/api/generate_report'
    ]
    
    print("🧪 Testing API Endpoints")
    print("="*40)
    
    for endpoint in endpoints:
        try:
            url = f"{base_url}{endpoint}"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if 'error' in data:
                    print(f"❌ {endpoint}: Error - {data['error']}")
                else:
                    print(f"✅ {endpoint}: Working")
            else:
                print(f"❌ {endpoint}: HTTP {response.status_code}")
                
        except requests.exceptions.RequestException as e:
            print(f"❌ {endpoint}: Connection error - {e}")
    
    print("\n🌐 Testing Dashboard Page")
    try:
        response = requests.get(f"{base_url}/", timeout=10)
        if response.status_code == 200:
            print("✅ Dashboard page: Working")
        else:
            print(f"❌ Dashboard page: HTTP {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Dashboard page: Connection error - {e}")

def start_flask_app():
    """Start the Flask application"""
    print("🚀 Starting Flask application...")
    
    # Change to the correct directory
    os.chdir('/Users/manu/ASCIIDocs/WA3546-CAP/wa3546-adp-data-program-projects/supporting/labs/benefits-optimization/benefits-app')
    
    # Start the Flask app
    process = subprocess.Popen([
        sys.executable, 'app_simple.py'
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for the server to start
    print("⏳ Waiting for server to start...")
    time.sleep(5)
    
    return process

def main():
    """Main test function"""
    print("🔧 Benefits Optimization Dashboard API Test")
    print("="*50)
    
    # Start the Flask app
    flask_process = start_flask_app()
    
    try:
        # Test the API endpoints
        test_api_endpoints()
        
        print("\n📊 Test Summary:")
        print("If all endpoints show ✅, the dashboard is working correctly!")
        print("If any show ❌, there may be data loading or chart rendering issues.")
        
    finally:
        # Clean up
        print("\n🧹 Cleaning up...")
        flask_process.terminate()
        flask_process.wait()

if __name__ == "__main__":
    main()