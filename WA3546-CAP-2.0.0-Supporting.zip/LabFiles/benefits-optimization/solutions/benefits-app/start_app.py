#!/usr/bin/env python3
"""
Startup script for TechLance Benefits Optimization Dashboard
Handles initialization and error checking
"""

import os
import sys
import traceback
from pathlib import Path

def check_data_files():
    """Check if required data files exist"""
    data_path = Path(__file__).parent.parent / 'assets' / 'data'
    required_files = [
        'usage_data.csv',
        'employee_data.csv', 
        'benefits_data.csv',
        'feedback_data.csv'
    ]
    
    missing_files = []
    for file in required_files:
        if not (data_path / file).exists():
            missing_files.append(file)
    
    if missing_files:
        print("❌ Missing required data files:")
        for file in missing_files:
            print(f"   - {file}")
        print(f"\nPlease ensure all CSV files are in: {data_path}")
        return False
    
    print("✅ All required data files found")
    return True

def check_dependencies():
    """Check if required Python packages are installed"""
    try:
        import flask
        import pandas
        import numpy
        import plotly
        import sklearn
        print("✅ All required packages installed")
        return True
    except ImportError as e:
        print(f"❌ Missing required package: {e}")
        print("Please run: pip install -r requirements.txt")
        return False

def main():
    """Main startup function"""
    print("🚀 Starting TechLance Benefits Optimization Dashboard")
    print("="*60)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Check data files
    if not check_data_files():
        sys.exit(1)
    
    # Try to start the application
    try:
        print("\n📊 Initializing dashboard...")
        from app import app
        
        print("✅ Dashboard initialized successfully")
        print("\n🌐 Starting web server...")
        print("📱 Dashboard will be available at: http://localhost:5003")
        print("🔧 Press Ctrl+C to stop the server")
        print("="*60)
        
        # Start the Flask app
        app.run(debug=True, host='0.0.0.0', port=5003)
        
    except Exception as e:
        print(f"\n❌ Error starting application: {e}")
        print("\nFull error traceback:")
        traceback.print_exc()
        print("\n💡 Common solutions:")
        print("1. Ensure all data files are in the correct location")
        print("2. Check that all required packages are installed")
        print("3. Verify Python version compatibility (3.8+)")
        sys.exit(1)

if __name__ == "__main__":
    main()