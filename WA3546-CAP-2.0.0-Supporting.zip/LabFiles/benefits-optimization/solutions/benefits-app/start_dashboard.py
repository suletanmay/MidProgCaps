#!/usr/bin/env python3
"""
Simple start script for the Benefits Optimization Dashboard
"""

import os
import sys
import subprocess
import webbrowser
import time

def main():
    """Start the dashboard and open in browser"""
    print("🚀 Starting TechLance Benefits Optimization Dashboard")
    print("=" * 55)
    
    # Change to the correct directory
    app_dir = "/Users/manu/ASCIIDocs/WA3546-CAP/wa3546-adp-data-program-projects/supporting/labs/benefits-optimization/benefits-app"
    os.chdir(app_dir)
    
    print("📁 Working directory:", os.getcwd())
    print("🌐 Dashboard URL: http://localhost:5002")
    print("🔧 Press Ctrl+C to stop the server")
    print("=" * 55)
    
    try:
        # Start the Flask app
        print("⏳ Starting Flask application...")
        process = subprocess.Popen([sys.executable, 'app_simple.py'])
        
        # Wait a moment for server to start
        time.sleep(3)
        
        # Open in browser
        print("🌐 Opening dashboard in browser...")
        webbrowser.open('http://localhost:5002')
        
        # Wait for the process to complete
        process.wait()
        
    except KeyboardInterrupt:
        print("\n\n🛑 Stopping dashboard...")
        process.terminate()
        process.wait()
        print("✅ Dashboard stopped successfully")
    
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)