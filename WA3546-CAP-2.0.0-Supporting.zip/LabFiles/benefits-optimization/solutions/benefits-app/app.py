"""
TechLance Solutions Benefits Optimization Analytics Dashboard
Flask application for Phase 4: Analytics Dashboard
"""

import os
import sys
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.utils
import json
from flask import Flask, render_template, request, jsonify, send_from_directory
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

def clean_nan_values(obj):
    """Recursively clean NaN values from nested dictionaries and lists"""
    if isinstance(obj, dict):
        return {k: clean_nan_values(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan_values(item) for item in obj]
    elif isinstance(obj, (float, np.floating)):
        return 0.0 if pd.isna(obj) else float(obj)
    elif isinstance(obj, (int, np.integer)):
        return int(obj)
    else:
        return obj

# Add current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import our analysis modules
from src.data_processor import DataProcessor
from src.ml_models import MLModels
from src.recommender import RecommenderSystem
from src.report_generator import ReportGenerator

app = Flask(__name__)
app.config['SECRET_KEY'] = 'benefits-optimization-dashboard-2024'

# Initialize our data processor
data_processor = DataProcessor()

@app.route('/')
def dashboard():
    """Main dashboard route"""
    return render_template('dashboard.html')

@app.route('/api/overview')
def api_overview():
    """API endpoint for overview metrics"""
    try:
        # Get filter parameters
        department = request.args.get('department', 'all')
        age_group = request.args.get('age_group', 'all')
        benefit_type = request.args.get('benefit_type', 'all')
        
        # Get filtered data
        merged_data = data_processor.get_filtered_data(
            department=department,
            age_group=age_group,
            benefit_type=benefit_type
        )
        
        # Calculate key metrics (handle NaN values)
        total_employees = merged_data['EmployeeID'].nunique()
        total_benefits = merged_data['BenefitSubType'].nunique()
        total_budget = merged_data['BenefitCost'].sum()
        avg_satisfaction = merged_data['SatisfactionScore'].mean()
        avg_usage = merged_data['UsageFrequency'].mean()
        
        # Replace NaN with 0 for JSON serialization
        avg_satisfaction = 0 if pd.isna(avg_satisfaction) else avg_satisfaction
        avg_usage = 0 if pd.isna(avg_usage) else avg_usage
        
        # Department breakdown
        dept_breakdown = merged_data.groupby('Department').agg({
            'EmployeeID': 'nunique',
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean'
        }).round(2)
        
        # Replace NaN values in department breakdown
        dept_breakdown = dept_breakdown.fillna(0).to_dict('index')
        
        # Age group breakdown
        age_breakdown = merged_data.groupby('age_group').agg({
            'EmployeeID': 'nunique',
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean'
        }).round(2)
        
        # Replace NaN values in age breakdown
        age_breakdown = age_breakdown.fillna(0).to_dict('index')
        
        response_data = {
            'total_employees': total_employees,
            'total_benefits': total_benefits,
            'total_budget': f"${total_budget:,.0f}",
            'avg_satisfaction': round(avg_satisfaction, 2),
            'avg_usage': round(avg_usage, 2),
            'dept_breakdown': dept_breakdown,
            'age_breakdown': age_breakdown,
            'filters_applied': {
                'department': department,
                'age_group': age_group,
                'benefit_type': benefit_type
            }
        }
        
        # Clean NaN values before JSON serialization
        response_data = clean_nan_values(response_data)
        return jsonify(response_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/utilization')
def api_utilization():
    """API endpoint for utilization analysis"""
    try:
        # Get filter parameters
        department = request.args.get('department', 'all')
        age_group = request.args.get('age_group', 'all')
        benefit_type = request.args.get('benefit_type', 'all')
        
        # Get filtered data
        merged_data = data_processor.get_filtered_data(
            department=department,
            age_group=age_group,
            benefit_type=benefit_type
        )
        
        # Benefit utilization by subtype
        benefit_utilization = merged_data.groupby('BenefitSubType').agg({
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean',
            'BenefitCost': 'mean',
            'EmployeeID': 'nunique'
        }).round(2)
        
        # Replace NaN values with 0 for JSON serialization
        benefit_utilization = benefit_utilization.fillna(0)
        
        # Create utilization chart
        fig = px.scatter(
            benefit_utilization.reset_index(),
            x='UsageFrequency',
            y='SatisfactionScore',
            size='EmployeeID',
            color='BenefitCost',
            hover_name='BenefitSubType',
            title='Benefit Utilization vs Satisfaction',
            labels={
                'UsageFrequency': 'Average Usage Frequency',
                'SatisfactionScore': 'Average Satisfaction Score',
                'BenefitCost': 'Average Cost'
            }
        )
        
        fig.update_layout(
            height=500,
            showlegend=True,
            hovermode='closest'
        )
        
        return jsonify({
            'chart': json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder),
            'data': benefit_utilization.to_dict('index')
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/segments')
def api_segments():
    """API endpoint for employee segment analysis"""
    try:
        merged_data = data_processor.get_merged_data()
        
        # Get segment analysis
        segment_analysis = merged_data.groupby('employee_segment').agg({
            'Age': 'mean',
            'Tenure': 'mean',
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean',
            'BenefitCost': 'mean',
            'EmployeeID': 'nunique'
        }).round(2)
        
        # Create segment comparison chart
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('Usage by Segment', 'Satisfaction by Segment', 
                          'Age Distribution', 'Tenure Distribution'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}],
                   [{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        segments = segment_analysis.index
        
        # Usage by segment
        fig.add_trace(
            go.Bar(x=segments, y=segment_analysis['UsageFrequency'], 
                   name='Usage', marker_color='blue'),
            row=1, col=1
        )
        
        # Satisfaction by segment
        fig.add_trace(
            go.Bar(x=segments, y=segment_analysis['SatisfactionScore'], 
                   name='Satisfaction', marker_color='green'),
            row=1, col=2
        )
        
        # Age distribution
        fig.add_trace(
            go.Bar(x=segments, y=segment_analysis['Age'], 
                   name='Age', marker_color='orange'),
            row=2, col=1
        )
        
        # Tenure distribution
        fig.add_trace(
            go.Bar(x=segments, y=segment_analysis['Tenure'], 
                   name='Tenure', marker_color='red'),
            row=2, col=2
        )
        
        fig.update_layout(height=600, showlegend=False)
        
        # Get detailed segment analysis
        detailed_analysis = data_processor.get_segment_analysis()
        
        return jsonify({
            'chart': json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder),
            'data': segment_analysis.to_dict('index'),
            'detailed_analysis': detailed_analysis
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/recommendations')
def api_recommendations():
    """API endpoint for recommendations"""
    try:
        # Get recommendations from our system
        rec_system = RecommenderSystem(data_processor)
        recommendations = rec_system.get_business_recommendations()
        
        return jsonify(recommendations)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/roi_analysis')
def api_roi_analysis():
    """API endpoint for ROI analysis"""
    try:
        merged_data = data_processor.get_merged_data()
        
        # Calculate ROI metrics
        roi_analysis = merged_data.groupby('BenefitSubType').agg({
            'ROI': 'mean',
            'BenefitCost': 'sum',
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean'
        }).round(3)
        
        # Create ROI quadrant chart
        fig = px.scatter(
            roi_analysis.reset_index(),
            x='BenefitCost',
            y='ROI',
            size='UsageFrequency',
            color='SatisfactionScore',
            hover_name='BenefitSubType',
            title='ROI Analysis: Cost vs ROI',
            labels={
                'BenefitCost': 'Total Cost',
                'ROI': 'ROI Score',
                'UsageFrequency': 'Usage Frequency',
                'SatisfactionScore': 'Satisfaction'
            }
        )
        
        # Add quadrant lines
        cost_median = roi_analysis['BenefitCost'].median()
        roi_median = roi_analysis['ROI'].median()
        
        fig.add_hline(y=roi_median, line_dash="dash", annotation_text="Median ROI")
        fig.add_vline(x=cost_median, line_dash="dash", annotation_text="Median Cost")
        
        fig.update_layout(height=500)
        
        return jsonify({
            'chart': json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder),
            'data': roi_analysis.to_dict('index')
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/filter_data')
def api_filter_data():
    """API endpoint for filtered data"""
    try:
        # Get filter parameters
        department = request.args.get('department', 'all')
        age_group = request.args.get('age_group', 'all')
        benefit_type = request.args.get('benefit_type', 'all')
        
        # Apply filters
        filtered_data = data_processor.get_filtered_data(
            department=department,
            age_group=age_group,
            benefit_type=benefit_type
        )
        
        # Calculate filtered metrics
        metrics = {
            'total_employees': filtered_data['EmployeeID'].nunique(),
            'avg_satisfaction': round(filtered_data['SatisfactionScore'].mean(), 2),
            'avg_usage': round(filtered_data['UsageFrequency'].mean(), 2),
            'total_cost': f"${filtered_data['BenefitCost'].sum():,.0f}"
        }
        
        return jsonify(metrics)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/reports')
def reports():
    """Reports page"""
    return render_template('reports.html')

@app.route('/api/generate_report')
def api_generate_report():
    """Generate strategic recommendations report"""
    try:
        report_gen = ReportGenerator()
        report = report_gen.generate_executive_report()
        
        return jsonify(report)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/detailed_insights')
def api_detailed_insights():
    """API endpoint for detailed underperforming benefits and upselling opportunities"""
    try:
        # Get recommendations from our system
        rec_system = RecommenderSystem(data_processor)
        recommendations = rec_system.get_business_recommendations()
        
        # Get merged data for additional analysis
        merged_data = data_processor.get_merged_data()
        
        # Calculate underperforming benefits details
        underperforming_details = []
        if 'awareness_campaigns' in recommendations:
            for item in recommendations['awareness_campaigns']:
                benefit_data = merged_data[merged_data['BenefitSubType'] == item['benefit']]
                if not benefit_data.empty:
                    underperforming_details.append({
                        'benefit': item['benefit'],
                        'usage': item['usage'],
                        'satisfaction': item['satisfaction'],
                        'recommendation': item['recommendation'],
                        'employee_count': benefit_data['EmployeeID'].nunique(),
                        'total_cost': benefit_data['BenefitCost'].sum(),
                        'avg_cost_per_employee': benefit_data['BenefitCost'].mean(),
                        'departments_affected': benefit_data['Department'].value_counts().to_dict(),
                        'potential_impact': 'High' if item['usage'] < 2 else 'Medium'
                    })
        
        # Calculate upselling opportunities details
        upselling_details = []
        if 'upselling_opportunities' in recommendations:
            for item in recommendations['upselling_opportunities']:
                category_data = merged_data[merged_data['BenefitType'] == item['category']]
                if not category_data.empty:
                    upselling_details.append({
                        'category': item['category'],
                        'potential_users': item['potential_users'],
                        'recommendation': item['recommendation'],
                        'current_users': category_data['EmployeeID'].nunique(),
                        'avg_satisfaction': category_data['SatisfactionScore'].mean(),
                        'estimated_revenue': item['potential_users'] * category_data['BenefitCost'].mean(),
                        'top_departments': category_data['Department'].value_counts().head(3).to_dict(),
                        'opportunity_score': 'High' if item['potential_users'] > 100 else 'Medium'
                    })
        
        return jsonify({
            'underperforming_benefits': underperforming_details,
            'upselling_opportunities': upselling_details,
            'summary': {
                'total_underperforming': len(underperforming_details),
                'total_upselling': len(upselling_details),
                'potential_cost_savings': sum(item['total_cost'] for item in underperforming_details if item['potential_impact'] == 'High'),
                'potential_revenue': sum(item['estimated_revenue'] for item in upselling_details if item['opportunity_score'] == 'High')
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/reset_cache')
def api_reset_cache():
    """API endpoint to reset application cache"""
    try:
        global data_processor
        # Reinitialize data processor to reload all data
        data_processor = DataProcessor()
        
        return jsonify({
            'status': 'success',
            'message': 'Cache reset successfully',
            'timestamp': datetime.now().isoformat(),
            'records_loaded': len(data_processor.get_merged_data())
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/static/<path:filename>')
def static_files(filename):
    """Serve static files"""
    return send_from_directory('static', filename)

@app.route('/test')
def test_dashboard():
    """Test dashboard route"""
    return send_from_directory('.', 'test_dashboard.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)