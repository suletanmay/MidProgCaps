#!/usr/bin/env python3
"""
Debug script to test Flask API endpoints
"""
import os
import sys
import traceback
import json

# Add current directory to path
sys.path.insert(0, os.path.dirname(__file__))

def test_flask_app():
    """Test Flask app initialization and endpoints"""
    print("🔍 Testing Flask app initialization...")
    
    try:
        from app import app, data_processor
        print("✅ Flask app imported successfully")
        
        # Test data processor instance
        merged_data = data_processor.get_merged_data()
        print(f"✅ Data processor has {len(merged_data)} records")
        
    except Exception as e:
        print(f"❌ Failed to import Flask app: {e}")
        traceback.print_exc()
        return False
    
    # Test API endpoints
    with app.test_client() as client:
        
        # Test overview endpoint
        try:
            print("\n🔍 Testing /api/overview endpoint...")
            response = client.get('/api/overview')
            print(f"  - Response status: {response.status_code}")
            
            if response.status_code == 200:
                data = json.loads(response.data)
                print(f"  - Total employees: {data.get('total_employees')}")
                print(f"  - Total benefits: {data.get('total_benefits')}")
                print(f"  - Total budget: {data.get('total_budget')}")
                print(f"  - Avg satisfaction: {data.get('avg_satisfaction')}")
                print(f"  - Avg usage: {data.get('avg_usage')}")
                print("✅ Overview endpoint working")
            else:
                print(f"❌ Overview endpoint failed: {response.data}")
                
        except Exception as e:
            print(f"❌ Error testing overview endpoint: {e}")
            traceback.print_exc()
        
        # Test utilization endpoint
        try:
            print("\n🔍 Testing /api/utilization endpoint...")
            response = client.get('/api/utilization')
            print(f"  - Response status: {response.status_code}")
            
            if response.status_code == 200:
                data = json.loads(response.data)
                print(f"  - Chart data length: {len(data.get('chart', ''))}")
                print(f"  - Data records: {len(data.get('data', {}))}")
                print("✅ Utilization endpoint working")
            else:
                print(f"❌ Utilization endpoint failed: {response.data}")
                
        except Exception as e:
            print(f"❌ Error testing utilization endpoint: {e}")
            traceback.print_exc()
        
        # Test segments endpoint
        try:
            print("\n🔍 Testing /api/segments endpoint...")
            response = client.get('/api/segments')
            print(f"  - Response status: {response.status_code}")
            
            if response.status_code == 200:
                data = json.loads(response.data)
                print(f"  - Chart data length: {len(data.get('chart', ''))}")
                print(f"  - Data records: {len(data.get('data', {}))}")
                print("✅ Segments endpoint working")
            else:
                print(f"❌ Segments endpoint failed: {response.data}")
                
        except Exception as e:
            print(f"❌ Error testing segments endpoint: {e}")
            traceback.print_exc()
        
        # Test ROI endpoint
        try:
            print("\n🔍 Testing /api/roi_analysis endpoint...")
            response = client.get('/api/roi_analysis')
            print(f"  - Response status: {response.status_code}")
            
            if response.status_code == 200:
                data = json.loads(response.data)
                print(f"  - Chart data length: {len(data.get('chart', ''))}")
                print(f"  - Data records: {len(data.get('data', {}))}")
                print("✅ ROI analysis endpoint working")
            else:
                print(f"❌ ROI analysis endpoint failed: {response.data}")
                
        except Exception as e:
            print(f"❌ Error testing ROI analysis endpoint: {e}")
            traceback.print_exc()
        
        # Test recommendations endpoint
        try:
            print("\n🔍 Testing /api/recommendations endpoint...")
            response = client.get('/api/recommendations')
            print(f"  - Response status: {response.status_code}")
            
            if response.status_code == 200:
                data = json.loads(response.data)
                print(f"  - Recommendations data: {type(data)}")
                print("✅ Recommendations endpoint working")
            else:
                print(f"❌ Recommendations endpoint failed: {response.data}")
                
        except Exception as e:
            print(f"❌ Error testing recommendations endpoint: {e}")
            traceback.print_exc()
    
    print("\n🎉 Flask app testing completed!")
    return True

if __name__ == "__main__":
    test_flask_app()