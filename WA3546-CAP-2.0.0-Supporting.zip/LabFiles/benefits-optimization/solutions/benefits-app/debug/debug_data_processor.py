#!/usr/bin/env python3
"""
Debug script to test data processor and identify issues
"""
import os
import sys
import traceback

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_data_processor():
    """Test the data processor with detailed debugging"""
    print("🔍 Starting data processor debugging...")
    
    # Test data path resolution
    print(f"Current working directory: {os.getcwd()}")
    
    # Test if data directory exists
    data_path = os.path.join(os.path.dirname(__file__), '..', 'assets', 'data')
    abs_data_path = os.path.abspath(data_path)
    print(f"Expected data path: {abs_data_path}")
    print(f"Data directory exists: {os.path.exists(abs_data_path)}")
    
    if os.path.exists(abs_data_path):
        print("Files in data directory:")
        for file in os.listdir(abs_data_path):
            file_path = os.path.join(abs_data_path, file)
            print(f"  - {file} (size: {os.path.getsize(file_path)} bytes)")
    
    # Test importing the data processor
    try:
        print("\n🔍 Testing data processor import...")
        from src.data_processor import DataProcessor
        print("✅ DataProcessor imported successfully")
    except Exception as e:
        print(f"❌ Failed to import DataProcessor: {e}")
        traceback.print_exc()
        return False
    
    # Test initializing the data processor
    try:
        print("\n🔍 Testing data processor initialization...")
        processor = DataProcessor()
        print("✅ DataProcessor initialized successfully")
    except Exception as e:
        print(f"❌ Failed to initialize DataProcessor: {e}")
        traceback.print_exc()
        return False
    
    # Test getting merged data
    try:
        print("\n🔍 Testing merged data retrieval...")
        merged_data = processor.get_merged_data()
        print(f"✅ Merged data retrieved: {len(merged_data)} records")
        print(f"  - Columns: {list(merged_data.columns)}")
        print(f"  - Unique employees: {merged_data['EmployeeID'].nunique()}")
        print(f"  - Unique benefits: {merged_data['BenefitSubType'].nunique()}")
    except Exception as e:
        print(f"❌ Failed to get merged data: {e}")
        traceback.print_exc()
        return False
    
    # Test API endpoints logic
    try:
        print("\n🔍 Testing overview metrics calculation...")
        total_employees = merged_data['EmployeeID'].nunique()
        total_benefits = merged_data['BenefitSubType'].nunique()
        total_budget = merged_data['BenefitCost'].sum()
        avg_satisfaction = merged_data['SatisfactionScore'].mean()
        avg_usage = merged_data['UsageFrequency'].mean()
        
        print(f"  - Total employees: {total_employees}")
        print(f"  - Total benefits: {total_benefits}")
        print(f"  - Total budget: ${total_budget:,.0f}")
        print(f"  - Avg satisfaction: {avg_satisfaction:.2f}")
        print(f"  - Avg usage: {avg_usage:.2f}")
        print("✅ Overview metrics calculated successfully")
    except Exception as e:
        print(f"❌ Failed to calculate overview metrics: {e}")
        traceback.print_exc()
        return False
    
    # Test visualization data preparation
    try:
        print("\n🔍 Testing visualization data preparation...")
        
        # Test utilization data
        benefit_utilization = merged_data.groupby('BenefitSubType').agg({
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean',
            'BenefitCost': 'mean',
            'EmployeeID': 'nunique'
        }).round(2)
        print(f"  - Benefit utilization data: {len(benefit_utilization)} records")
        
        # Test segment analysis
        if 'employee_segment' in merged_data.columns:
            segment_analysis = merged_data.groupby('employee_segment').agg({
                'Age': 'mean',
                'Tenure': 'mean',
                'UsageFrequency': 'mean',
                'SatisfactionScore': 'mean',
                'BenefitCost': 'mean',
                'EmployeeID': 'nunique'
            }).round(2)
            print(f"  - Segment analysis data: {len(segment_analysis)} records")
        
        # Test ROI analysis
        if 'ROI' in merged_data.columns:
            roi_analysis = merged_data.groupby('BenefitSubType').agg({
                'ROI': 'mean',
                'BenefitCost': 'sum',
                'UsageFrequency': 'mean',
                'SatisfactionScore': 'mean'
            }).round(3)
            print(f"  - ROI analysis data: {len(roi_analysis)} records")
        
        print("✅ Visualization data preparation successful")
    except Exception as e:
        print(f"❌ Failed to prepare visualization data: {e}")
        traceback.print_exc()
        return False
    
    print("\n🎉 All data processor tests passed!")
    return True

def test_plotly_charts():
    """Test Plotly chart generation"""
    print("\n🔍 Testing Plotly chart generation...")
    
    try:
        import plotly.express as px
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
        import plotly.utils
        import json
        print("✅ Plotly imports successful")
    except Exception as e:
        print(f"❌ Failed to import Plotly: {e}")
        return False
    
    # Test basic chart creation
    try:
        from src.data_processor import DataProcessor
        processor = DataProcessor()
        merged_data = processor.get_merged_data()
        
        # Test scatter plot
        benefit_utilization = merged_data.groupby('BenefitSubType').agg({
            'UsageFrequency': 'mean',
            'SatisfactionScore': 'mean',
            'BenefitCost': 'mean',
            'EmployeeID': 'nunique'
        }).round(2)
        
        fig = px.scatter(
            benefit_utilization.reset_index(),
            x='UsageFrequency',
            y='SatisfactionScore',
            size='EmployeeID',
            color='BenefitCost',
            hover_name='BenefitSubType',
            title='Benefit Utilization vs Satisfaction'
        )
        
        # Test JSON serialization
        chart_json = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
        print(f"✅ Chart JSON generated: {len(chart_json)} characters")
        
    except Exception as e:
        print(f"❌ Failed to generate Plotly chart: {e}")
        traceback.print_exc()
        return False
    
    print("✅ Plotly chart generation successful")
    return True

if __name__ == "__main__":
    success = test_data_processor()
    if success:
        test_plotly_charts()
    else:
        print("\n❌ Data processor test failed. Check the errors above.")