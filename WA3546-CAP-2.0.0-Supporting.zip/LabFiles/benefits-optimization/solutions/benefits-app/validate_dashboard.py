#!/usr/bin/env python3
"""
Comprehensive validation script for the Benefits Optimization Dashboard
Tests data loading, chart generation, and API functionality
"""

import requests
import json
import time
import subprocess
import sys
import os
from pathlib import Path

def validate_data_files():
    """Validate that all required data files exist"""
    print("📁 Validating Data Files")
    print("-" * 30)
    
    data_path = Path("../assets/data")
    required_files = [
        'usage_data.csv',
        'employee_data.csv',
        'benefits_data.csv',
        'feedback_data.csv'
    ]
    
    all_good = True
    for file in required_files:
        file_path = data_path / file
        if file_path.exists():
            size = file_path.stat().st_size
            print(f"✅ {file}: {size:,} bytes")
        else:
            print(f"❌ {file}: Missing")
            all_good = False
    
    return all_good

def validate_api_responses():
    """Validate API responses contain expected data"""
    print("\n🔍 Validating API Responses")
    print("-" * 30)
    
    base_url = "http://localhost:5002"
    
    # Test overview endpoint
    try:
        response = requests.get(f"{base_url}/api/overview", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ Overview API: {data['error']}")
            return False
        
        # Check required fields
        required_fields = ['total_employees', 'total_benefits', 'avg_satisfaction', 'avg_usage']
        for field in required_fields:
            if field in data:
                print(f"✅ Overview API - {field}: {data[field]}")
            else:
                print(f"❌ Overview API - Missing field: {field}")
                return False
                
    except Exception as e:
        print(f"❌ Overview API: {e}")
        return False
    
    # Test utilization endpoint (chart data)
    try:
        response = requests.get(f"{base_url}/api/utilization", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ Utilization API: {data['error']}")
            return False
        
        if 'chart' in data:
            chart_data = json.loads(data['chart'])
            if 'data' in chart_data and len(chart_data['data']) > 0:
                print(f"✅ Utilization Chart: {len(chart_data['data'])} data series")
            else:
                print("❌ Utilization Chart: No data")
                return False
        else:
            print("❌ Utilization API: No chart data")
            return False
            
    except Exception as e:
        print(f"❌ Utilization API: {e}")
        return False
    
    # Test segments endpoint
    try:
        response = requests.get(f"{base_url}/api/segments", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ Segments API: {data['error']}")
            return False
        
        if 'chart' in data:
            chart_data = json.loads(data['chart'])
            if 'data' in chart_data and len(chart_data['data']) > 0:
                print(f"✅ Segments Chart: {len(chart_data['data'])} data series")
            else:
                print("❌ Segments Chart: No data")
                return False
        else:
            print("❌ Segments API: No chart data")
            return False
            
    except Exception as e:
        print(f"❌ Segments API: {e}")
        return False
    
    # Test ROI analysis endpoint
    try:
        response = requests.get(f"{base_url}/api/roi_analysis", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ ROI Analysis API: {data['error']}")
            return False
        
        if 'chart' in data:
            chart_data = json.loads(data['chart'])
            if 'data' in chart_data and len(chart_data['data']) > 0:
                print(f"✅ ROI Chart: {len(chart_data['data'])} data series")
            else:
                print("❌ ROI Chart: No data")
                return False
        else:
            print("❌ ROI Analysis API: No chart data")
            return False
            
    except Exception as e:
        print(f"❌ ROI Analysis API: {e}")
        return False
    
    # Test recommendations endpoint
    try:
        response = requests.get(f"{base_url}/api/recommendations", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ Recommendations API: {data['error']}")
            return False
        
        if 'awareness_campaigns' in data and len(data['awareness_campaigns']) > 0:
            print(f"✅ Recommendations: {len(data['awareness_campaigns'])} awareness campaigns")
        else:
            print("❌ Recommendations: No awareness campaigns")
            return False
            
    except Exception as e:
        print(f"❌ Recommendations API: {e}")
        return False
    
    # Test report generation endpoint
    try:
        response = requests.get(f"{base_url}/api/generate_report", timeout=10)
        data = response.json()
        
        if 'error' in data:
            print(f"❌ Report Generation API: {data['error']}")
            return False
        
        if 'executive_summary' in data and 'strategic_recommendations' in data:
            print("✅ Report Generation: Complete strategic report generated")
        else:
            print("❌ Report Generation: Incomplete report")
            return False
            
    except Exception as e:
        print(f"❌ Report Generation API: {e}")
        return False
    
    return True

def validate_dependencies():
    """Validate all required Python packages are installed"""
    print("\n📦 Validating Dependencies")
    print("-" * 30)
    
    required_packages = [
        'flask',
        'pandas',
        'numpy',
        'plotly',
        'sklearn',
        'requests'
    ]
    
    all_good = True
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package}: Not installed")
            all_good = False
    
    return all_good

def start_flask_app():
    """Start the Flask application for testing"""
    print("\n🚀 Starting Flask Application")
    print("-" * 30)
    
    # Change to the correct directory
    os.chdir('/Users/manu/ASCIIDocs/WA3546-CAP/wa3546-adp-data-program-projects/supporting/labs/benefits-optimization/benefits-app')
    
    # Start the Flask app
    process = subprocess.Popen([
        sys.executable, 'app_simple.py'
    ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Wait for the server to start
    print("⏳ Waiting for server to start...")
    time.sleep(6)
    
    # Check if server is running
    try:
        response = requests.get("http://localhost:5002/", timeout=5)
        if response.status_code == 200:
            print("✅ Flask app started successfully")
            return process
        else:
            print(f"❌ Flask app returned status code: {response.status_code}")
            return None
    except requests.exceptions.RequestException:
        print("❌ Flask app failed to start")
        return None

def main():
    """Main validation function"""
    print("🔧 Benefits Optimization Dashboard Validation")
    print("=" * 50)
    
    # Step 1: Validate data files
    if not validate_data_files():
        print("\n❌ Data file validation failed!")
        return False
    
    # Step 2: Validate dependencies
    if not validate_dependencies():
        print("\n❌ Dependency validation failed!")
        return False
    
    # Step 3: Start Flask app and validate APIs
    flask_process = start_flask_app()
    if not flask_process:
        return False
    
    try:
        # Step 4: Validate API responses
        if not validate_api_responses():
            print("\n❌ API validation failed!")
            return False
        
        print("\n🎉 VALIDATION COMPLETE!")
        print("=" * 50)
        print("✅ All systems are working correctly!")
        print("✅ Data is loading properly")
        print("✅ Charts are rendering correctly")
        print("✅ API endpoints are functional")
        print("\n🌐 Dashboard is ready at: http://localhost:5002")
        print("\n📊 Key Features Available:")
        print("  • Interactive Plotly charts")
        print("  • Real-time data filtering")
        print("  • Strategic recommendations")
        print("  • Executive reports")
        print("  • Mobile-responsive design")
        
        return True
        
    finally:
        # Clean up
        print("\n🧹 Cleaning up...")
        if flask_process:
            flask_process.terminate()
            flask_process.wait()

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)